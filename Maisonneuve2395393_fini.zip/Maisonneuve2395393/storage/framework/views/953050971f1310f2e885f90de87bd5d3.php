<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .nav-tabs .nav-item {
            margin: 2px;
        }

        .nav-tabs .nav-link {
            text-decoration: none;
        }

        .userInfo {
            border: 2px solid black;
            padding: 2rem;
        }

        .article-container-fr, .article-container-en {
            margin: 1rem;
        }

        button {
            margin: 1rem;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <ul class="nav nav-tabs">

                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home.index')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Article
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="<?php echo e(route('article.index')); ?>"><?php echo app('translator')->get('My Articles'); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('article.create')); ?>"><?php echo app('translator')->get('Create Article'); ?></a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo app('translator')->get('File Directory'); ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="<?php echo e(route('file.index')); ?>"><?php echo app('translator')->get('File Directory'); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('file.upload')); ?>"><?php echo app('translator')->get('Upload files'); ?></a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('user.index')); ?>"><?php echo app('translator')->get('List Users'); ?> </a></li>
                    <?php endif; ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo app('translator')->get('Language'); ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="<?php echo e(route('lang', 'fr')); ?>"><?php echo app('translator')->get('French'); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('lang', 'en')); ?>"><?php echo app('translator')->get('English'); ?></a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav nav-tabs">
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('Login'); ?></a></li>
                    <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('logout')); ?>"><?php echo app('translator')->get('Logout'); ?></a></li>
                    <p class="nav-item"><?php echo app('translator')->get('lang.text_welcome'); ?> - <?php echo e(Auth::user()->name); ?></p>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('user.create')); ?>"><?php echo app('translator')->get('Registration'); ?></a></li>
                </ul>
            </div>
        </nav>
    </header>
    <main>
        <div class="container my-5">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
    <footer class="footer mt-auto py-3 bg-light">
        <div class="container">
            <span class="text-muted"><?php echo app('translator')->get('lang.text_copyright'); ?></span>
        </div>
    </footer>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</html>
<?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/layouts/app.blade.php ENDPATH**/ ?>