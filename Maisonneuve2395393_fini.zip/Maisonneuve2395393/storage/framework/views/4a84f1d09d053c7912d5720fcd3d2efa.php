
<?php $__env->startSection('title', 'Edit Etudiant'); ?>
<?php $__env->startSection('content'); ?>


<!-- <a href="<?php echo e(route('etudiant.index')); ?>"><< Liste Etudiant</a> -->
<h1>Edit Etudiant</h1>

<form action="<?php echo e(route('etudiant.edit', $etudiant->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom</label>
                            <input type="text" class="form-control" id="nom" name="nom" value="<?php echo e(old('nom', $etudiant->nom)); ?>">
                            <?php if($errors->has('nom')): ?>
                            <div class="text-danger mt-2">
                                <?php echo e($errors->first('nom')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="adresse" class="form-label">Adresse</label>
                            <input type="text" class="form-control" id="adresse" name="adresse" rows="3" value="<?php echo e(old('adresse', $etudiant->adresse)); ?>" >
                            <?php if($errors->has('adresse')): ?>
                            <div class="text-danger mt-2">
                                <?php echo e($errors->first('adresse')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="telephone" class="form-label">telephone</label>
                            <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo e(old('telephone', $etudiant->telephone)); ?>" >
                            <?php if($errors->has('telephone')): ?>
                            <div class="text-danger mt-2">
                                <?php echo e($errors->first('telephone')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">email</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo e(old('email', $etudiant->email)); ?>">
                            <?php if($errors->has('email')): ?>
                            <div class="text-danger mt-2">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="date_de_naissance" class="form-label">Date de naissance</label>
                            <input type="date" class="form-control" id="date_de_naissance" name="date_de_naissance" value="<?php echo e(old('date_de_naissance', $etudiant->date_de_naissance)); ?>">
                            <?php if($errors->has('date_de_naissance')): ?>
                            <div class="text-danger mt-2">
                                <?php echo e($errors->first('date_de_naissance')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <select name="ville" id="ville">
                        <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ville->id); ?>" <?php if($etudiant->ville_id == $ville->id ): ?> selected <?php endif; ?> > <?php echo e($ville->nom); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/etudiant/edit.blade.php ENDPATH**/ ?>