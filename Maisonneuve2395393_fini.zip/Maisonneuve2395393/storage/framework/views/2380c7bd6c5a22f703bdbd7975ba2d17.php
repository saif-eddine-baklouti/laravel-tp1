
<?php $__env->startSection('title', 'List Files'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
<?php $__empty_1 = true; $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6">
        <div class="card mb-3">
            <div class="card-body">
                <form action="<?php echo e(route('file.download', $file->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>    
                    <input type="hidden" name="slug" value="<?php echo e($file->slug); ?>">
                    <button type="submit" class="btn btn-primary btn-sm mb-2"><?php echo app('translator')->get('Download'); ?> : <?php echo e($file->nom); ?></button>
                </form>
                <p class="mb-0"><?php echo app('translator')->get('Author'); ?>: <?php echo e($file->user->name); ?></p>
            </div>
            <?php if(Auth::user()->id == $file->user->id): ?>
            <form action="<?php echo e(route('file.delete', $file->id)); ?>"  method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col">
        <div class="alert alert-danger"><?php echo app('translator')->get('lang.text_empty_file'); ?></div>
    </div>
<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/file/index.blade.php ENDPATH**/ ?>