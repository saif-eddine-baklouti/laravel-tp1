<?php $__env->startSection('title', trans('lang.text_welcome')); ?>
<?php $__env->startSection('content'); ?>
<div class="masthead d-flex align-items-center">
            <div class="container px-4 px-lg-5 text-center">
                <h1 class="mb-1">Maisonexxuve</h1>
                <h3 class="mb-5"><em><?php echo app('translator')->get('lang.text_welcome_paragraph'); ?></em></h3>
                <!-- <a class="btn btn-primary btn-xl" href="<?php echo e(route('etudiant.index')); ?>"><?php echo app('translator')->get('lang.text_welcome_btn'); ?></a> -->
            </div>
        </div>

        <div class="container">
        <h1 class="my-5"> <?php echo app('translator')->get('List Articles'); ?></h1>

        <a href="<?php echo e(route('article.create')); ?>" class="btn btn-primary mb-3"> <?php echo app('translator')->get('Create Article'); ?></a>
        
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 list-group-item">
                    <div class="card mb-3">
                        <div class="card-body">
                            <a href="#"><?php echo e($article->titre); ?></a>
                            <p><?php echo app('translator')->get('Author'); ?> : <?php echo e($article->user->name); ?></p>
                            <a href="<?php echo e(route('article.show', $article->id)); ?>" class="btn btn-sm btn-outline-primary">Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col">
                    <div class="alert alert-danger"><?php echo app('translator')->get('lang.text_empty_article'); ?></div>
                </div>
            <?php endif; ?>  
            <div class="mt-5">
                <?php echo e($articles->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/welcome.blade.php ENDPATH**/ ?>