
<?php $__env->startSection('title', 'Modifier Article'); ?>
<?php $__env->startSection('content'); ?>

<form class="d-flex bg-white justify-content-center p-5 mt-5 mb-5 special-form" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
<div class="article-container-fr">
<div class="g-3 align-items-center mb-4">
        <div>
            <label for="inputTitreFr" class="col-form-label"><?php echo app('translator')->get('Article Title'); ?> (FR)</label>
        </div>
        <div>
            <input type="text" name="titre_fr" value="<?php echo e(old('titre_fr') ?? $article->titre_fr); ?>" id="inputTitreFr" class="form-control <?php $__errorArgs = ['titre_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-describedby="TitreEnHelpInline" >
        </div>


        <?php $__errorArgs = ['titre_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="alert alert-danger d-inline-block m-2 p-2"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
    </div>

    <div class="g-3 align-items-center mb-4">
        <div class="col-auto">
            <label for="inputCorpFr" class="col-form-label"><?php echo app('translator')->get('Context Of The Article'); ?> (FR)</label>
        </div>
        <div>
            <textarea name="context_fr" id="inputCorpFr" class="form-control <?php $__errorArgs = ['context_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-describedby="CorpFrHelpInline" rows="10"><?php echo e(old('context_fr') ?? $article->context_fr); ?></textarea>
        </div>

        <?php $__errorArgs = ['context_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="alert alert-danger d-inline-block m-2 p-2"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
</div>

<div class="article-container-en">
<div class="g-3 align-items-center mb-4">
        <div>
            <label for="inputTitreEn" class="col-form-label"><?php echo app('translator')->get('Article Title'); ?> (EN)</label>
        </div>
        <div>
            <input type="text" name="titre_en" value="<?php echo e(old('titre_en') ?? $article->titre_en); ?>" id="inputTitreEn" class="form-control <?php $__errorArgs = ['titre_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-describedby="TitreEnHelpInline">
        </div>
        
        <?php $__errorArgs = ['titre_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="alert alert-danger d-inline-block m-2 p-2"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>

    <div class="g-3 align-items-center mb-4">
        <div>
            <label for="inputCorpEn" class="col-form-label"><?php echo app('translator')->get('Context Of The Article'); ?> (EN)</label>
        </div>
        <div>
            <textarea name="context_en" id="inputCorpEn" class="form-control <?php $__errorArgs = ['context_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-describedby="CorpEnHelpInline" rows="10"><?php echo e(old('context_en') ?? $article->context_en); ?></textarea>
        </div>

        <?php $__errorArgs = ['context_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="alert alert-danger d-inline-block m-2 p-2"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>

</div>

<div>
    <button type="submit" class="btn btn-primary"><?php echo e(__('Enregistrer')); ?></button>
</div>
</form>
        <form  method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/article/edit.blade.php ENDPATH**/ ?>