
<?php $__env->startSection('title', 'Mes Article'); ?>

<div class="row list-group">
            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 list-group-item">
                    <div class="card mb-3">
                        <div class="card-body">
                            <a href="#"><?php echo e($article->titre); ?></a>
                            <p><?php echo app('translator')->get('Author'); ?> : <?php echo e($article->user->name); ?></p>
                            <a href="<?php echo e(route('article.show', $article->id)); ?>" class="btn btn-sm btn-outline-primary">Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col">
                    <div class="alert alert-danger">There are no students to display!</div>
                </div>
            <?php endif; ?>  
            <div class="mt-5">
                <?php echo e($articles->links()); ?>

            </div>
        </div>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/article/index.blade.php ENDPATH**/ ?>