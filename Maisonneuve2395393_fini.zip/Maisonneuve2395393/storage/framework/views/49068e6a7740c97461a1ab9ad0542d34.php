
<?php $__env->startSection('title', @trans('List Users')); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
        <h1 class="my-5"> <?php echo app('translator')->get('List Users'); ?></h1>

        <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary mb-3"> <?php echo app('translator')->get('Create User'); ?></a>

        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($user->name); ?></h5>
                            <a href="<?php echo e(route('user.show', $user->id)); ?>" class="btn btn-sm btn-outline-primary"><?php echo app('translator')->get('Details'); ?></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col">
                    <div class="alert alert-danger"><?php echo app('translator')->get('lang.text_empty_user'); ?></div>
                </div>
                <?php endif; ?>  
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/user/index.blade.php ENDPATH**/ ?>