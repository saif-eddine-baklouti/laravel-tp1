
<?php $__env->startSection('title', trans('lang.text_welcome')); ?>
<?php $__env->startSection('content'); ?>
<div>
<h2> <?php echo e(Config::get('app.locale') == 'en' ? $article->titre_en :  $article->titre_fr); ?> </h2>

<p> <?php echo e(Config::get('app.locale') == 'en' ? $article->context_en :  $article->context_fr); ?></p>
<?php if(auth()->guard()->check()): ?>
<?php if(Auth::user()->id == $article->user_id): ?>
    
        <div class="container-fluid">
            <a href="<?php echo e(route('article.edit', $article->id)); ?>">modifier</a>
            <form  method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
        </form>
        </div>
</div>    
<?php endif; ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/article/show.blade.php ENDPATH**/ ?>