
<?php $__env->startSection('title', trans('User')); ?>
<?php $__env->startSection('content'); ?>

        <div class="userInfo">
            <h3>Infos <?php echo app('translator')->get('User'); ?> </h3>
        <ul >
            <li> <strong> <?php echo app('translator')->get('Username'); ?> : </strong> <?php echo e($user->name); ?> </li> 
            <li><strong><?php echo app('translator')->get('Email Address'); ?> : </strong> <?php echo e($user->email); ?> </li>
        </ul>
        <?php if(Auth::user()->id == $user->id): ?>
        <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-sm btn-outline-success"><?php echo app('translator')->get('Edit'); ?></a>
    
        <form  method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-sm btn-danger"><?php echo app('translator')->get('Delete'); ?></button>
        </form>
        <?php endif; ?>
        </div>
<div  class="userInfo">
    <h3>Infos <?php echo app('translator')->get('Student'); ?> </h3>
        <ul>
            <li> <strong><?php echo app('translator')->get('Name'); ?> : </strong> <?php echo e($etudiant->nom); ?> </li> 
            <li><strong><?php echo app('translator')->get('Address'); ?> : </strong> <?php echo e($etudiant->adresse); ?> </li>
            <li><strong><?php echo app('translator')->get('Phone'); ?> : </strong> <?php echo e($etudiant->telephone); ?> </li>
            <li><strong><?php echo app('translator')->get('Email Address'); ?> : </strong> <?php echo e($etudiant->email); ?> </li>
            <li><strong><?php echo app('translator')->get('Date Of Birth'); ?>: </strong> <?php echo e($etudiant->date_de_naissance); ?> </li>
            <li><strong><?php echo app('translator')->get('City'); ?> : </strong> <?php echo e($ville->nom); ?> </li>
        </ul>
        
        <?php if(Auth::user()->id == $user->id): ?>
        <a href="<?php echo e(route('etudiant.edit', $etudiant->id)); ?>" class="btn btn-sm btn-outline-success"><?php echo app('translator')->get('Edit'); ?></a>
    
        <form  method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-sm btn-danger"><?php echo app('translator')->get('Delete'); ?></button>
        </form>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/user/show.blade.php ENDPATH**/ ?>