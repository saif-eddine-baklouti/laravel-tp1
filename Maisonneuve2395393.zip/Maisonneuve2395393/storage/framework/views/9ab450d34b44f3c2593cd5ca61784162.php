
<?php $__env->startSection('title', 'Etudiant List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="my-5"> Etudiant List</h1>

        <a href="<?php echo e(route('etudiant.create')); ?>" class="btn btn-primary mb-3"> Create Etudiant</a>

        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($etudiant->nom); ?></h5>
                            <a href="<?php echo e(route('etudiant.show', $etudiant->id)); ?>" class="btn btn-sm btn-outline-primary">Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col">
                    <div class="alert alert-danger">There are no students to display!</div>
                </div>
            <?php endif; ?>  
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/etudiant/index.blade.php ENDPATH**/ ?>