
<?php $__env->startSection('title', 'Etudiant'); ?>
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('etudiant.index')); ?>"><< Liste Etudiant</a>
<div class="col-md-6">
        <ul>
            <li> <strong>Nom: </strong> <?php echo e($etudiant->nom); ?> </li> 
            <li><strong>Adresse: </strong> <?php echo e($etudiant->adresse); ?> </li>
            <li><strong>Telephone: </strong> <?php echo e($etudiant->telephone); ?> </li>
            <li><strong>Email: </strong> <?php echo e($etudiant->email); ?> </li>
            <li><strong>Date de naissance: </strong> <?php echo e($etudiant->date_de_naissance); ?> </li>
            <li><strong>Ville: </strong> <?php echo e($ville->nom); ?> </li>
        </ul>
        
        
        <a href="<?php echo e(route('etudiant.edit', $etudiant->id)); ?>" class="btn btn-sm btn-outline-success">Edit</a>
        <form  method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\laravel-tp1\Maisonneuve2395393\resources\views/etudiant/show.blade.php ENDPATH**/ ?>